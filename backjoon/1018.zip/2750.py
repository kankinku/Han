N = int(input())
Num = []
for _ in range(N):
    Num.append(int(input()))

Num.sort()
for i in Num:
    print(i)